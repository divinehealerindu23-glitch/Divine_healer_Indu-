DIVINE HEALER INDU — WEBSITE FILES

CONTENTS
- index.html: website content and structure
- styles.css: responsive purple, lavender, gold and blush-pink design
- script.js: mobile navigation and WhatsApp enquiry form

PREVIEW
Open index.html in a modern browser. An internet connection is required for the Google Fonts.
The WhatsApp booking form opens WhatsApp with a pre-filled enquiry to +91 89207 02407.

ADD YOUR PHOTOGRAPH
1. Choose a clear portrait photograph.
2. Copy it into this same folder and name it indu-photo.jpg.
3. Open index.html in a text editor.
4. Find the comment "Replace the portrait placeholder with your photograph".
5. Replace the portrait-placeholder div with:
   <img src="indu-photo.jpg" alt="Divine Healer Indu" style="width:100%;height:440px;object-fit:cover">

PUBLISH
Upload index.html, styles.css, script.js and your portrait image (if added) to the public root folder of your hosting provider. Keep the three website files in the same folder.

BEFORE LAUNCH
- Add your photograph.
- Confirm the WhatsApp number and appointment process.
- Add any preferred session fees, exact Delhi address/area, testimonials (with permission), and social links if desired.
- Consider adding a privacy policy before collecting personal information.

IMPORTANT
Spiritual readings and energy practices are described as reflective/supportive services, not guaranteed outcomes or substitutes for professional medical, legal, mental-health or financial advice.
