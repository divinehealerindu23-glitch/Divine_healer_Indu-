const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('bookingForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const name = document.getElementById('name').value.trim();
  const service = document.getElementById('service').value;
  const mode = document.getElementById('mode').value;
  const message = document.getElementById('message').value.trim();
  const text = `Hello Indu, I would like to enquire about a session.%0A%0AName: ${encodeURIComponent(name)}%0AService: ${encodeURIComponent(service)}%0APreference: ${encodeURIComponent(mode)}%0AMessage: ${encodeURIComponent(message || 'I would like to know more.')}`;
  window.open(`https://wa.me/918920702407?text=${text}`, '_blank', 'noopener');
});
