import React, { useEffect, useRef, useState } from "react";
import {
  Sparkles, Moon, Star, Sun, Heart, HandHeart, Eye, Coins, Briefcase,
  Scale, Compass, Hash, Phone, Flower2, ShieldCheck, Flame, Gem,
  BookOpen, CalendarCheck, MapPin, ArrowRight, Check, Send, Clock,
  BadgeCheck, Lock, Users
} from "lucide-react";
import { mountPlaceListMap, mapsDirectionsUrl } from "@meta-ai/artifact-maps/helpers";
import "@meta-ai/artifact-maps/index.css";

const SERVICES = [
  { name: "Tarot Card Reading", desc: "Clear, intuitive insight into love, work, decisions and what is unfolding next.", icon: BookOpen, tint: "#6b2fa8" },
  { name: "Akashic Reading", desc: "Gentle access to soul patterns, lessons and the deeper story behind your life.", icon: Eye, tint: "#9a7417" },
  { name: "Healing for Money", desc: "Release scarcity patterns and open the way to steady, aligned abundance.", icon: Coins, tint: "#b9872e" },
  { name: "Healing for Love & Marriage", desc: "Soften old wounds, restore closeness and invite a loving, committed bond.", icon: Heart, tint: "#c24d78" },
  { name: "Healing for Health", desc: "Calming energy work that supports rest, balance and the body’s own healing.", icon: HandHeart, tint: "#5b8a5f" },
  { name: "7 Chakra Healing", desc: "Balance all seven energy centres from grounding to higher connection.", icon: Flower2, tint: "#7c3fc1" },
  { name: "Aura Cleansing", desc: "Clear heaviness, other people’s energy and stagnant feelings from your field.", icon: Sparkles, tint: "#9a7417" },
  { name: "Aura Healing", desc: "Repair, strengthen and brighten your aura so you feel protected and radiant.", icon: Sun, tint: "#c69a2e" },
  { name: "Black Magic Removal", desc: "Careful, compassionate clearing of negative energy, cords and harmful influences.", icon: ShieldCheck, tint: "#5b2f8f" },
  { name: "Legal Matters Healing", desc: "Steady the energy around disputes, paperwork and decisions with clarity.", icon: Scale, tint: "#9a7417" },
  { name: "Healing for Career", desc: "Remove blocks around visibility, growth, interviews and new opportunities.", icon: Briefcase, tint: "#a65a3d" },
  { name: "Dowser Reading", desc: "Focused dowsing guidance for questions that need a clear yes, no or direction.", icon: Compass, tint: "#6b2fa8" },
  { name: "Numerology Birth Chart", desc: "Your numbers, cycles and life path — understood in a warm, practical way.", icon: Hash, tint: "#b9872e" },
  { name: "Career Guidance", desc: "Find the work that fits your gifts, timing and next chapter.", icon: Compass, tint: "#7c3fc1" },
  { name: "Marriage Guidance", desc: "Honest, kind guidance for partnership, commitment and shared decisions.", icon: Heart, tint: "#c24d78" },
  { name: "Marriage Charts", desc: "A thoughtful look at timing, compatibility and the path of a union.", icon: CalendarCheck, tint: "#9a7417" },
  { name: "Compatibility Check", desc: "Understand how two people connect, communicate and grow together.", icon: Users, tint: "#5b8a5f" },
  { name: "Money Guidance", desc: "Practical spiritual guidance for choices, timing and financial confidence.", icon: Coins, tint: "#b9872e" },
  { name: "Life Problems", desc: "When everything feels tangled, find one clear, supported next step.", icon: Flower2, tint: "#c24d78" },
  { name: "Health Guidance", desc: "Gentle insight into balance, routines and the support your wellbeing needs.", icon: HandHeart, tint: "#5b8a5f" },
  { name: "Name Compatibility", desc: "Explore how names carry energy and how they harmonise together.", icon: Star, tint: "#c69a2e" },
  { name: "Mobile No. Compatibility", desc: "Check the energy and harmony carried by a mobile number.", icon: Phone, tint: "#6b2fa8" },
];

const CHAKRAS = [
  { name: "Root", focus: "Safety · Grounding", color: "#ef5350", desc: "Feel steady, safe and supported." },
  { name: "Sacral", focus: "Creativity · Feeling", color: "#ff8a3d", desc: "Reconnect with joy and flow." },
  { name: "Solar Plexus", focus: "Confidence · Power", color: "#e5b72e", desc: "Trust your choices again." },
  { name: "Heart", focus: "Love · Compassion", color: "#66bb6a", desc: "Open to giving and receiving love." },
  { name: "Throat", focus: "Truth · Expression", color: "#4aa8ff", desc: "Speak clearly and be heard." },
  { name: "Third Eye", focus: "Intuition · Insight", color: "#7c6cff", desc: "See beyond doubt and fear." },
  { name: "Crown", focus: "Connection · Peace", color: "#c084fc", desc: "Return to calm and purpose." },
];

const STEPS = [
  { n: "01", title: "Share your concern", text: "Tell Indu what feels heavy, stuck or unclear — in your own words." },
  { n: "02", title: "Choose your reading / healing", text: "Pick the service that calls to you, or ask for guidance to choose." },
  { n: "03", title: "In-person session in Delhi", text: "Meet in person for a calm, private session held with care." },
  { n: "04", title: "Receive guidance & healing", text: "Leave with clarity, practices and lighter, aligned energy." },
];

type ApiResult = { saved: number; remaining: number; error: string | null; reloadError: string | null } | null;

async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action, args }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json?.error) {
    const msg = typeof json?.error === "string" ? json.error : json?.error?.message || "The request could not be completed.";
    throw new Error(msg);
  }
  return json.data;
}

export default function App() {
  const [form, setForm] = useState({ name: "", phone: "", service: "Tarot Card Reading", message: "" });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ApiResult>(null);
  const [bookingCount, setBookingCount] = useState<number | null>(null);
  const [mapUnavailable, setMapUnavailable] = useState(false);

  const mapRef = useRef<HTMLDivElement | null>(null);
  const rowRefs = useRef<Array<HTMLDivElement | null>>([]);

  const place = { label: "In-person sessions in Delhi", lat: 28.63412, lng: 77.21688, approximate: true };
  const places = [{ label: place.label, lat: place.lat, lng: place.lng }];

  async function reloadRecords() {
    const data = await api("records.list", { collection: "bookings" });
    const records = Array.isArray(data?.records) ? data.records : [];
    setBookingCount(records.length);
  }

  useEffect(() => {
    let alive = true;
    reloadRecords().catch(() => { if (alive) setBookingCount(null); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;
    const rows = rowRefs.current.filter(Boolean) as HTMLElement[];
    const map = mountPlaceListMap(mapRef.current, { places, rows }, () => setMapUnavailable(true));
    return () => map?.destroy();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function createRow(row: typeof form) {
    const key = `booking-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    await api("records.create", {
      collection: "bookings",
      idempotency_key: key,
      value: { name: row.name.trim(), phone: row.phone.trim(), service: row.service, message: row.message.trim(), createdAt: new Date().toISOString() },
    });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) return;
    const rows = [form];
    setBusy(true);
    let saved = 0;
    let error: string | null = null;
    try {
      for (const row of rows) {
        await createRow(row);
        saved += 1;
      }
    } catch (err) {
      error = err instanceof Error ? err.message : String(err);
    }
    let reloadError: string | null = null;
    try { await reloadRecords(); } catch (err) { reloadError = err instanceof Error ? err.message : String(err); }
    setResult({ saved, remaining: rows.length - saved, error, reloadError });
    setBusy(false);
    if (!error && saved === 1) setForm({ name: "", phone: "", service: "Tarot Card Reading", message: "" });
  }

  const inputCls = "w-full rounded-xl border-2 border-[#D8B4FE] bg-white px-4 py-3 text-[15px] text-[#4B0082] outline-none focus:border-[#8B00BB] focus:ring-2 focus:ring-[#FFD700]/60 placeholder:text-[#9A6BC0]";

  const navLink = "text-white hover:text-[#FFD700] hover:underline decoration-[#FFD700] decoration-2 underline-offset-8";

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }} className="min-h-[100dvh] bg-[var(--bg)] text-[var(--ink)] overflow-x-clip">
      {/* Header — #8B00BB */}
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-40 border-b-2 border-[#FFD700] bg-[#8B00BB]/95 shadow-[0_10px_30px_rgba(75,0,130,.45)] backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <a href="#top" className="flex items-center gap-2.5">
            <span className="relative grid h-10 w-10 place-items-center rounded-full border-2 border-[#FFD700] bg-gradient-to-br from-[#8B00BB] to-[#4B0082] text-[#F5D67B]"><Moon size={20} /><span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-[#FFD700]" /></span>
            <span className="leading-none">
              <span className="inline-block rounded-full border-2 border-[#FFD700] bg-gradient-to-br from-[#E6CCFF] via-white to-[#FFE4F1] px-3 py-1 shadow-[0_0_18px_rgba(255,215,0,.55)]">
                <span className="serif block bg-gradient-to-r from-[#8B00BB] via-[#6A0DAD] to-[#4B0082] bg-clip-text text-[20px] font-bold tracking-wide text-transparent drop-shadow-[0_1px_0_rgba(255,255,255,.9)] sm:text-[22px]">Divine_healer_Indu</span>
              </span>
              <span className="mt-1 block text-[10px] uppercase tracking-[0.22em] text-[#F5D67B]">Heal · Align · Attract · Transform</span>
            </span>
          </a>
          <nav className="flex flex-wrap items-center gap-4 text-[13px] font-medium text-white sm:gap-6 sm:text-sm">
            <a className={navLink} href="#about">About</a>
            <a className={navLink} href="#services">Services</a>
            <a className={`${navLink} hidden sm:inline`} href="#chakras">Chakras</a>
            <a className={navLink} href="#how">How it works</a>
            <a href="#booking" className="btn-primary rounded-full px-4 py-2 font-semibold">Book a Session</a>
          </nav>
        </div>
      </header>

      {/* HERO — #8B00BB to #4B0082 */}
      <section id="top" className="fleck-field-dark relative overflow-x-clip bg-gradient-to-br from-[#8B00BB] via-[#6A0DAD] to-[#4B0082]">
        <div className="pointer-events-none absolute inset-0">
          <div className="glow-orb absolute -top-24 left-1/2 h-[460px] w-[760px] -translate-x-1/2 rounded-full" />
          <div className="absolute bottom-0 left-0 h-[260px] w-[420px] rounded-full bg-[#FFD6E8]/30 blur-3xl" />
          <div className="absolute bottom-10 right-0 h-[220px] w-[380px] rounded-full bg-[#FFE4F1]/30 blur-3xl" />
          <Star className="twinkle absolute left-[10%] top-[16%] text-[#FFD700]" size={24} />
          <Star className="twinkle-slow absolute left-[20%] top-[54%] text-[#F5D67B]" size={15} />
          <Star className="twinkle absolute right-[15%] top-[12%] text-[#FFF6B8]" size={28} />
          <Star className="twinkle-slow absolute right-[25%] top-[60%] text-[#FFD700]" size={17} />
          <Star className="twinkle absolute left-[32%] top-[8%] text-[#FFD6E8]" size={14} />
          {/* Moon */}
          <div className="absolute right-[7%] top-[18%] hidden h-24 w-24 rounded-full bg-[#FFF6B8] shadow-[0_0_70px_26px_rgba(255,215,0,.55)] sm:block" />
          <div className="absolute right-[10%] top-[24%] hidden h-8 w-8 rounded-full bg-[#FFD6E8]/70 sm:block" />
          {/* Floating pyrite crystals */}
          <div className="pyrite floaty absolute left-[6%] top-[38%] hidden h-14 w-11 opacity-95 md:block" />
          <div className="pyrite-soft floaty absolute left-[14%] top-[68%] hidden h-9 w-8 opacity-90 md:block" style={{ animationDelay: "1s" }} />
          <div className="pyrite floaty absolute right-[6%] top-[62%] hidden h-16 w-12 opacity-95 md:block" style={{ animationDelay: ".6s" }} />
          <div className="pyrite-soft absolute left-[42%] top-[10%] hidden h-6 w-5 opacity-80 md:block" />
          <div className="pyrite floaty absolute left-[3%] top-[12%] hidden h-8 w-6 opacity-70 md:block" style={{ animationDelay: "1.4s" }} />
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-[#4B0082]/50 to-transparent" />
        </div>
        <div className="relative mx-auto max-w-6xl px-4 pb-14 pt-12 text-center sm:px-6 sm:pt-16">
          <p className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-[#FFD700] bg-[#4B0082]/70 px-4 py-1.5 text-[11px] uppercase tracking-[0.22em] text-[#F5D67B] shadow-sm"><Sparkles size={14} /> In-person healing · Delhi, India</p>
          <span className="inline-block max-w-full rounded-[2rem] border-2 border-[#FFD700] bg-gradient-to-br from-[#E6CCFF] via-white to-[#FFE4F1] px-5 py-3 shadow-[0_18px_50px_rgba(255,215,0,.35),0_10px_30px_rgba(75,0,130,.35)] sm:px-8 sm:py-4">
            <h1 className="serif bg-gradient-to-r from-[#8B00BB] via-[#6A0DAD] to-[#4B0082] bg-clip-text text-[clamp(2.1rem,9vw,5.2rem)] leading-[0.95] font-bold text-transparent drop-shadow-[0_2px_0_rgba(255,255,255,.9)] [overflow-wrap:anywhere]">Divine_healer_Indu</h1>
          </span>
          <p className="serif mt-4 text-[clamp(1.35rem,3.5vw,2.1rem)] italic text-[#F5D67B] drop-shadow-[0_1px_2px_rgba(42,0,77,.8)]">Heal • Align • Attract • Transform</p>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-[#F3E8FF] sm:text-lg">A calm, sacred space to release what weighs you down — and return to clarity, love, abundance, health and purpose. Held with warmth, privacy and deep spiritual care.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href="#booking" className="btn-primary inline-flex items-center gap-2 rounded-full px-6 py-3.5 font-semibold">Book a Session <ArrowRight size={18} /></a>
            <a href="#services" className="inline-flex items-center gap-2 rounded-full border-2 border-[#FFD700] bg-[#4B0082]/60 px-6 py-3.5 font-semibold text-white hover:bg-[#6A0DAD]">Explore Services</a>
          </div>
          <div className="mx-auto mt-10 grid max-w-3xl grid-cols-3 divide-x divide-[#FFD700]/50 rounded-2xl border-2 border-[#FFD700] bg-[#4B0082]/70 py-4 text-center shadow-[0_10px_30px_rgba(0,0,0,.35)] backdrop-blur-sm">
            <div><p className="serif text-xl font-bold text-[#F5D67B] sm:text-2xl">22</p><p className="text-[11px] uppercase tracking-wider text-[#F3E8FF]">Services</p></div>
            <div><p className="serif text-xl font-bold text-[#F5D67B] sm:text-2xl">7</p><p className="text-[11px] uppercase tracking-wider text-[#F3E8FF]">Chakras</p></div>
            <div><p className="serif text-xl font-bold text-[#F5D67B] sm:text-2xl">1:1</p><p className="text-[11px] uppercase tracking-wider text-[#F3E8FF]">In Delhi</p></div>
          </div>
          <p className="mt-6 text-xs tracking-[0.18em] uppercase text-[#F5D67B]">✦ Golden pyrite · Lavender light · Baby-pink calm ✦</p>
        </div>
        <div className="gold-line mx-auto max-w-6xl" />
      </section>

      {/* ABOUT — lavender */}
      <section id="about" className="bg-gradient-to-b from-[#E6CCFF] via-[#F3E8FF] to-[#FFE4F1]">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20">
        <div className="grid items-center gap-10 md:grid-cols-[1.05fr_0.95fr]">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#C9A227]">✦ About Indu</p>
            <h2 className="serif text-[clamp(2rem,5vw,3.2rem)] leading-tight text-[#8B00BB]">A healer who listens<br />before she <span className="gold-text-dark">guides.</span></h2>
            <div className="gold-underline mt-4" />
            <p className="mt-5 leading-relaxed text-[#6A0DAD]">Indu is a <strong className="text-[#8B00BB]">Reiki Grand Master</strong> and a <strong className="text-[#8B00BB]">Humkara &amp; Haleem Healer</strong>. Her work is intuitive, compassionate and deeply personal — clearing blocks, soothing the nervous system, and helping life align again with abundance, love, health and purpose.</p>
            <p className="mt-4 leading-relaxed text-[#6A0DAD]">Whether you arrive with a heavy heart, a difficult decision, or a longing for something more, you will be met without judgement — and guided with honesty, tenderness and spiritual strength.</p>
            <div className="mt-6 flex flex-wrap gap-2">
              {["Reiki Grand Master", "Humkara Healer", "Haleem Healer", "In-person · Delhi"].map((t) => (
                <span key={t} className="rounded-full border border-[#D4AF37] bg-[#FFE4F1] px-3.5 py-1.5 text-xs font-medium text-[#8B00BB]">{t}</span>
              ))}
            </div>
          </div>
          <div className="fleck-field-dark relative overflow-hidden rounded-[28px] border-2 border-[#FFD700] bg-gradient-to-br from-[#8B00BB] via-[#7B2CBF] to-[#6A0DAD] p-7 shadow-[var(--shadow)]">
            <Moon className="floaty absolute right-6 top-6 text-[#F5D67B]" size={42} />
            <div className="pyrite absolute bottom-5 right-5 h-12 w-10 opacity-90" />
            <p className="serif text-2xl leading-snug text-white">“You do not need to carry it all alone. Healing begins the moment you allow yourself to be held.”</p>
            <div className="mt-6 flex items-center gap-3">
              <span className="gold-foil grid h-12 w-12 place-items-center rounded-full font-bold text-[#4B0082]">I</span>
              <div><p className="font-semibold text-white">Indu</p><p className="text-sm text-[#F3E8FF]">Founder · Divine_healer_Indu</p></div>
            </div>
            <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-xl border border-[#FFD700]/70 bg-white/95 p-3"><MapPin className="mb-1 text-[#C9A227]" size={18} /><p className="font-medium text-[#8B00BB]">In-person sessions</p><p className="text-[#7B2CBF]">Delhi, India</p></div>
              <div className="rounded-xl border border-[#FFD700]/70 bg-white/95 p-3"><Lock className="mb-1 text-[#C9A227]" size={18} /><p className="font-medium text-[#8B00BB]">Private &amp; confidential</p><p className="text-[#7B2CBF]">Your story stays safe</p></div>
            </div>
          </div>
        </div>
        </div>
        <div className="gold-line mx-auto max-w-6xl" />
      </section>

      {/* SERVICES — #8B00BB */}
      <section id="services" className="fleck-field-dark bg-gradient-to-b from-[#8B00BB] via-[#6A0DAD] to-[#4B0082] py-14 text-white sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="max-w-2xl">
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#F5D67B]">✦ Services</p>
            <h2 className="serif text-[clamp(2rem,5vw,3.2rem)] leading-tight text-white">Choose the healing<br /><span className="gold-text">your heart is asking for</span></h2>
            <div className="gold-underline mt-4" />
            <p className="mt-4 text-[#F3E8FF]">Every session is personalised. If you are unsure where to begin, share your concern — Indu will gently guide you to the right reading or healing.</p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((s, idx) => {
              const Icon = s.icon;
              const soft = idx % 3 === 0 ? "bg-[#E6CCFF]" : idx % 3 === 1 ? "bg-white" : "bg-[#FFE4F1]";
              return (
                <article key={s.name} className={`card-glow fleck-field rounded-3xl border-2 border-[#FFD700] ${soft} p-5`}>
                  <span className="mb-4 grid h-11 w-11 place-items-center rounded-2xl border border-[#FFD700]/70 bg-[#8B00BB] shadow-sm text-[#FFD700]"><Icon size={22} /></span>
                  <h3 className="serif text-[22px] leading-tight text-[#8B00BB]">{s.name}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#4B0082]">{s.desc}</p>
                  <a href="#booking" className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-[#8B00BB] hover:text-[#C9A227]">Book this service <ArrowRight size={15} /></a>
                </article>
              );
            })}
          </div>
          <p className="mt-8 text-center text-sm text-[#F5D67B]">✦ Golden pyrite accents · Soft lavender &amp; baby-pink cards · Shimmering gold borders ✦</p>
        </div>
      </section>

      {/* CHAKRAS — lavender / baby pink */}
      <section id="chakras" className="bg-gradient-to-b from-[#FFE4F1] via-[#F3E8FF] to-[#E6CCFF]">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20">
        <div className="text-center">
          <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#C9A227]">✦ The Seven Chakras</p>
          <h2 className="serif text-[clamp(2rem,5vw,3.2rem)] text-[#8B00BB]">When energy flows, <span className="gold-text-dark">life flows</span></h2>
          <div className="gold-underline mx-auto mt-4" />
          <p className="mx-auto mt-3 max-w-2xl text-[#6A0DAD]">In 7 Chakra Healing, each centre is gently cleared and balanced — so you can feel grounded, open-hearted and deeply connected.</p>
        </div>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-7 lg:gap-2">
          {CHAKRAS.map((c, i) => (
            <div key={c.name} className="card-glow rounded-3xl border-2 border-[#FFD700] bg-white p-4 text-center">
              <span className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full text-white shadow-lg" style={{ background: c.color }}><Flower2 size={22} /></span>
              <p className="text-[11px] font-bold tracking-widest text-[#C9A227]">{String(i + 1).padStart(2, "0")}</p>
              <h3 className="serif text-xl text-[#8B00BB]">{c.name}</h3>
              <p className="mt-1 text-xs font-medium text-[#6A0DAD] [overflow-wrap:anywhere]">{c.focus}</p>
              <p className="mt-2 text-xs leading-relaxed text-[#7B2CBF] [overflow-wrap:anywhere]">{c.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-5 flex h-2 overflow-hidden rounded-full border border-[#FFD700]">
          {CHAKRAS.map((c) => <span key={c.name} className="flex-1" style={{ background: c.color }} />)}
        </div>
        </div>
        <div className="gold-line mx-auto max-w-6xl" />
      </section>

      {/* HOW IT WORKS + WHY — #8B00BB */}
      <section id="how" className="fleck-field-dark bg-gradient-to-br from-[#8B00BB] via-[#6A0DAD] to-[#4B0082] py-14 text-white sm:py-20">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-2">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#F5D67B]">✦ How it works</p>
            <h2 className="serif text-[clamp(2rem,5vw,3rem)] leading-tight text-white">A gentle path,<br />one step at a time</h2>
            <div className="gold-underline mt-4" />
            <div className="mt-8 space-y-4">
              {STEPS.map((s) => (
                <div key={s.n} className="flex gap-4 rounded-2xl border-2 border-[#FFD700] bg-[#F3E8FF] p-4 shadow-sm">
                  <span className="serif gold-text-dark text-3xl font-bold">{s.n}</span>
                  <div><h3 className="serif text-xl text-[#8B00BB]">{s.title}</h3><p className="mt-1 text-sm leading-relaxed text-[#6A0DAD]">{s.text}</p></div>
                </div>
              ))}
            </div>
          </div>
          <div id="why">
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#F5D67B]">✦ Why choose Indu</p>
            <h2 className="serif text-[clamp(2rem,5vw,3rem)] leading-tight text-white">Held by experience,<br />guided by heart</h2>
            <div className="gold-underline mt-4" />
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {[
                { icon: BadgeCheck, t: "Experienced Grand Master", d: "Deep training in Reiki, Humkara and Haleem healing." },
                { icon: HandHeart, t: "Personalised guidance", d: "No scripts. Every session is shaped around you." },
                { icon: Lock, t: "Confidential", d: "Your concerns and story are held with complete privacy." },
                { icon: MapPin, t: "In-person connection", d: "Real presence, real energy — in Delhi, face to face." },
              ].map((w) => (
                <div key={w.t} className="card-glow rounded-3xl border-2 border-[#FFD700] bg-white p-5">
                  <w.icon className="mb-3 text-[#C9A227]" size={26} />
                  <h3 className="serif text-xl text-[#8B00BB]">{w.t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#6A0DAD]">{w.d}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-start gap-3 rounded-3xl border-2 border-[#FFD700] bg-[#FFE4F1] p-5">
              <Flame className="mt-0.5 shrink-0 text-[#C9A227]" size={22} />
              <p className="text-sm leading-relaxed text-[#6A0DAD]">Healing is not about fear. It is about remembering your own light — and letting it shine again. <span className="font-semibold text-[#8B00BB]">Your session is a safe place to begin.</span></p>
            </div>
          </div>
        </div>
      </section>

      {/* BOOKING + MAP — lavender / baby pink */}
      <section id="booking" className="bg-gradient-to-b from-[#F3E8FF] via-[#FFE4F1] to-[#E6CCFF]">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20">
        <div className="grid gap-8 lg:grid-cols-[0.95fr_1.05fr]">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#C9A227]">✦ Book your slot</p>
            <h2 className="serif text-[clamp(2rem,5vw,3.2rem)] leading-tight text-[#8B00BB]">Begin your<br /><span className="gold-text-dark">healing journey</span></h2>
            <div className="gold-underline mt-4" />
            <p className="mt-4 leading-relaxed text-[#6A0DAD]">Share a few details and Indu will receive your request. <strong className="text-[#8B00BB]">In-person sessions in Delhi — book your slot.</strong></p>
            <div className="mt-6 space-y-3 text-sm text-[#6A0DAD]">
              <p className="flex items-center gap-2.5"><Clock size={17} className="text-[#C9A227]" /> Sessions are held in person, by appointment.</p>
              <p className="flex items-center gap-2.5"><Lock size={17} className="text-[#C9A227]" /> Your details stay private and confidential.</p>
              <p className="flex items-center gap-2.5"><Gem size={17} className="text-[#C9A227]" /> Come as you are — no preparation needed.</p>
            </div>

            <div className="mt-8 overflow-hidden rounded-3xl border-2 border-[#FFD700] bg-white shadow-[var(--shadow)]">
              <div className="border-b border-[#FFD700]/60 bg-[#8B00BB] p-4">
                <h3 className="serif text-xl text-white">Find us in Delhi</h3>
                <p className="mt-1 text-sm text-[#F3E8FF]">In-person sessions · Delhi, India</p>
              </div>
              {mapUnavailable ? (
                <p className="p-4 text-sm text-[#C9A227]">Map unavailable — see the location below.</p>
              ) : (
                <div ref={mapRef} className="h-[360px] w-full sm:h-[420px]" aria-label="Map of in-person sessions in Delhi" />
              )}
              <div ref={(el) => { rowRefs.current[0] = el; }} className="flex flex-wrap items-center justify-between gap-3 border-t border-[#FFD700]/60 bg-[#FDF7FF] p-4">
                <div>
                  <p className="font-semibold text-[#8B00BB]">1 · In-person sessions in Delhi</p>
                  <p className="text-sm text-[#7B2CBF]">Approximate location (city-level) · Delhi, India</p>
                </div>
                <a href={mapsDirectionsUrl({ label: place.label, lat: place.lat, lng: place.lng })} target="_blank" rel="noopener" className="inline-flex items-center gap-1.5 rounded-full border-2 border-[#C9A227] px-4 py-2 text-sm font-semibold text-[#8B00BB] hover:bg-[#FFE4F1]">Directions <ArrowRight size={15} /></a>
              </div>
            </div>
          </div>

          <div className="rounded-[28px] border-2 border-[#FFD700] bg-gradient-to-br from-white via-[#FFE4F1] to-[#F3E8FF] p-5 shadow-[var(--shadow)] sm:p-7">
            <h3 className="serif text-2xl text-[#8B00BB]">Request a session</h3>
            <p className="mt-1 text-sm text-[#7B2CBF]">Fill in the form — your request is saved securely.</p>
            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label htmlFor="name" className="mb-1.5 block text-sm font-medium text-[#8B00BB]">Your name *</label>
                <input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your full name" className={inputCls} />
              </div>
              <div>
                <label htmlFor="phone" className="mb-1.5 block text-sm font-medium text-[#8B00BB]">Phone / WhatsApp *</label>
                <input id="phone" required type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Your phone or WhatsApp number" className={inputCls} />
              </div>
              <div>
                <label htmlFor="service" className="mb-1.5 block text-sm font-medium text-[#8B00BB]">Service needed *</label>
                <select id="service" value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} className={inputCls}>
                  {SERVICES.map((s) => <option key={s.name} value={s.name}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="message" className="mb-1.5 block text-sm font-medium text-[#8B00BB]">Your message</label>
                <textarea id="message" rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Share a little about what you would like healing or guidance for…" className={`${inputCls} resize-y`} />
              </div>
              <button type="submit" disabled={busy} className="btn-primary flex w-full items-center justify-center gap-2 rounded-full px-6 py-3.5 font-semibold disabled:opacity-60">
                {busy ? "Saving your request…" : <>Send booking request <Send size={17} /></>}
              </button>
              <p className="text-center text-xs text-[#7B2CBF]">In-person sessions in Delhi · Book your slot{bookingCount !== null ? ` · ${bookingCount} request${bookingCount === 1 ? "" : "s"} received so far` : ""}</p>
              {result && (
                <div className={`rounded-2xl border p-4 text-sm ${result.error ? "border-red-400/50 bg-red-50 text-[#6b1f2a]" : "border-emerald-400/50 bg-emerald-50 text-[#14532d]"}`} role="status">
                  {result.error ? (
                    <p>Your request could not be saved. Saved: {result.saved} · Remaining: {result.remaining}. Error: <span className="[overflow-wrap:anywhere]">{result.error}</span></p>
                  ) : (
                    <p className="flex items-start gap-2"><Check className="mt-0.5 shrink-0 text-emerald-600" size={18} /> Thank you, {form.name ? "your request is on its way" : "your request has been saved"}. Saved: {result.saved} · Remaining: {result.remaining}. Indu will connect with you about your in-person session in Delhi.</p>
                  )}
                  {result.reloadError && <p className="mt-2">Could not refresh the list: <span className="[overflow-wrap:anywhere]">{result.reloadError}</span></p>}
                </div>
              )}
            </form>
          </div>
        </div>
        </div>
      </section>

      <footer className="fleck-field-dark border-t-2 border-[#FFD700] bg-gradient-to-r from-[#2A004D] via-[#6A0DAD] to-[#8B00BB] py-10 text-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-5 px-4 sm:px-6">
          <div>
            <p className="serif bg-gradient-to-r from-[#D8B4FE] via-[#E6CCFF] to-[#D8B4FE] bg-clip-text text-2xl font-bold text-transparent drop-shadow-[0_1px_2px_rgba(0,0,0,.45)]">Divine_healer_Indu</p>
            <p className="mt-1 text-sm font-medium text-[#F5D67B]">Heal • Align • Attract • Transform</p>
          </div>
          <div className="text-sm text-[#F3E8FF]">
            <p className="flex items-center gap-2"><MapPin size={15} className="text-[#FFD700]" /> Delhi, India</p>
            <p className="mt-1">In-person healing sessions · By appointment</p>
          </div>
          <a href="#booking" className="btn-primary rounded-full px-5 py-2.5 text-sm font-semibold">Book a Session</a>
        </div>
        <div className="gold-line mx-auto mt-8 max-w-6xl" />
        <p className="mt-6 text-center text-xs text-[#F3E8FF]">© {new Date().getFullYear()} Divine_healer_Indu · Delhi, India · Made with intention and light.</p>
      </footer>
    </div>
  );
}
